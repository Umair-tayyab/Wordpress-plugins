<?php
if (!is_user_logged_in()) {
    echo "<p>Please log in to access your profile.</p>";
    return;
}

global $wpdb;
$current_user_id = get_current_user_id();
$table_name = $wpdb->prefix . "bloodbank";

$user_data = $wpdb->get_row(
    $wpdb->prepare("SELECT * FROM $table_name WHERE user_id = %d", $current_user_id)
);

if (isset($_POST['submit']) && !$user_data) {
    $name       = sanitize_text_field($_POST['user_name']);
    $email      = sanitize_email($_POST['user_email']);
    $phone      = sanitize_text_field($_POST['user_phone']);
    $blood_type = sanitize_text_field($_POST['user_blood_type']);
    $status     = sanitize_text_field($_POST['user_status']);

    $insert = $wpdb->insert(
        $table_name,
        array(
            'name'        => $name,
            'email'       => $email,
            'phone'       => $phone,
            'blood_group' => $blood_type,
            'status'      => $status,
            'user_id'     => $current_user_id
        )
    );

    if ($insert) {
        echo "<div class='notice notice-success'><p>Data saved successfully!</p></div>";
        $user_data = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM $table_name WHERE user_id = %d", $current_user_id)
        );
    } else {
        echo "<div class='notice notice-error'><p>Error: " . esc_html($wpdb->last_error) . "</p></div>";
    }
}
?>

<?php if (!(esc_html($user_data -> status) == "yes")): ?>
    <form action="" method="POST">
        <label for="name">Name</label><br>
        <input type="text" name="user_name" id="name" class="regular-text" required><br>

        <label for="email">Email</label><br>
        <input type="email" name="user_email" id="email" class="regular-text" required><br>

        <label for="phone">Phone</label><br>
        <input type="text" name="user_phone" id="phone" class="regular-text" required><br>

        <label for="blood_type">Blood Group</label><br>
        <select name="user_blood_type" required>
            <option value="">Select</option>
            <option value="A+">A+</option>
            <option value="A-">A-</option>
            <option value="B+">B+</option>
            <option value="B-">B-</option>
            <option value="O+">O+</option>
            <option value="O-">O-</option>
            <option value="AB+">AB+</option>
            <option value="AB-">AB-</option>
        </select><br>

        <label for="status">Status</label><br>
        <select name="user_status" required>
            <option value="yes">Yes</option>
            <option value="no">No</option>
        </select><br><br>

        <input type="submit" name="submit" value="Submit" class="button button-primary">
    </form>
<?php else: ?>
    <h2>Your Donor Record</h2>
    <table class="wp-list-table widefat fixed striped">
        <thead>
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Blood Group</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td><?php echo esc_html($user_data->name); ?></td>
                <td><?php echo esc_html($user_data->email); ?></td>
                <td><?php echo esc_html($user_data->phone); ?></td>
                <td><?php echo esc_html($user_data->blood_group); ?></td>
                <td><?php echo esc_html($user_data->status); ?></td>
            </tr>
        </tbody>
    </table>
<?php endif; ?>
