<form action="<?php echo get_the_permalink();?>" method="POST">
    <label for="usrname">Username</label><br>
    <input type="text" name="usrname"><br>

    <label for="userpassword">Password</label><br>
    <input type="password" name="userpassword"><br>

    <input type="submit" value="Login" name="userlogin">
</form>
