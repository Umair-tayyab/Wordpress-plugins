<?php


?>

<form action="" method="POST">
    <label for="name">Name</label></br>
    <input type="text" name="usrname" ></br>
    <label for="email">Emial</label></br>
    <input type="email" name="useremail" ></br>
    <label for="password">Password</label></br>
    <input type="password" name="userpassword" ></br>
    <input type="submit" value="SigUp" name="usersignup">
</form>