<?php
echo "<div class='wrap'><h2>All Blood Donor <a href='?page=add-donor'><button class='button button-secondary'>Add Donor</button></a>
</h2><p>List of All doners.</p></div>";

global $wpdb;
$table_name = $wpdb -> prefix . "bloodbank";

if (isset($_POST['search'])) {
    $sql = "SELECT * FROM `$table_name` WHERE `blood_group` LIKE '%" . $_POST['search_term'] . "%'";
}else{
    $sql = "SELECT * FROM `$table_name`";
}

$result = $wpdb -> get_results($sql);

?>
<a href="?page=bloodbank"><button class="button button-primary">All</button></a>
<a href="?page=bloodbank-pending"><button class="button button-primary">Pending</button></a>
<a href="?page=bloodbank-published"><button class="button button-primary">Published</button></a>


<form action="" method="POST" id="bloodbank-form" style="margin: 10px 0px">
    <input type="hidden" name="page" value="bloodbank-published" >
    <input type="text" id="regular-text" name="search_term" placeholder="Search Donor By Blood Group">
    <input type="submit" name="search" value="Search Donor" class="button button-secondary">
</form>

<table class="wp-list-table widefat fixed striped table-view-list posts">
    <thead>
        <tr>
            <td><b>ID</b></td>
            <td><b>Name</b></td>
            <td><b>Email</b></td>
            <td><b>Phone</b></td>
            <td><b>Blood Group</b></td>
            <td><b>Status</b></td>
            <td><b>Edit</b></td>
            <td><b>Delete</b></td>
        </tr>
    </thead>
    <tbody id="bloodbank-table">
        <tr>
        <?php foreach($result as $data): ?>
            <?php if (esc_html($data -> status) == 'yes'){
                echo "<tr>
            <th> " . esc_html($data -> id) . "</th>
            <th> " . esc_html($data -> name) . "</th>
            <th> " . esc_html($data -> email) . "</th>
            <th> " . esc_html($data -> phone) . "</th>
            <th> " . esc_html($data -> blood_group) . "</th>
            <th> " . esc_html($data -> status) . "</th>
            <th><a href=' class='button button-primary'>Edit</a></th>
            <th><a href=' class='button button-danger'>Delete</a></th>
        </tr>";
            }
            ?>
        <?php endforeach;?>
            
    </tbody>
</table>