<?php

global $wpdb;
$table_name = $wpdb -> prefix . "bloodbank";

$id = esc_sql($_GET['id']);

$result = $wpdb -> delete(
    $table_name, array('id' => $id ),
);


if ($result) {
    echo "Donor deleting...";
}