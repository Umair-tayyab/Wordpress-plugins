<?php
echo "<div class='wrap'><h2>Update Donor</h2><p>Please update donor carefully.</p></div>";

global $wpdb;
$table_name = $wpdb->prefix . "bloodbank";
$id = intval($_GET['id']);

$sql = $wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $id);
$donor = $wpdb->get_row($sql);

if (!$donor) {
    echo "<div class='notice notice-error'><p>Invalid Donor ID.</p></div>";
    return;
}

if (isset($_POST['update'])) {
    $name       = sanitize_text_field($_POST['name']);
    $email      = sanitize_email($_POST['email']);
    $phone      = sanitize_text_field($_POST['phone']);
    $blood_type = sanitize_text_field($_POST['blood_type']);
    $status     = sanitize_text_field($_POST['status']);

    $updated = $wpdb->update(
        $table_name,
        array(
            'name'        => $name,
            'email'       => $email,
            'phone'       => $phone,
            'blood_group' => $blood_type,
            'status'      => $status,
        ),
        array('id' => $id)
    );

    if ($updated !== false) {
        echo "<div class='notice notice-success is-dismissible'><p>Donor updated successfully!</p></div>";
        $donor = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $id));
    } else {
        echo "<div class='notice notice-error is-dismissible'><p>Update failed or no changes made. Error: " . esc_html($wpdb->last_error) . "</p></div>";
    }
}
?>

<form action="" method="POST">
    <label for="name">Name</label><br>
    <input type="text" name="name" id="name" class="regular-text" value="<?php echo esc_attr($donor->name); ?>" required><br>

    <label for="email">Email</label><br>
    <input type="email" name="email" id="email" class="regular-text" value="<?php echo esc_attr($donor->email); ?>" required><br>

    <label for="phone">Phone</label><br>
    <input type="text" name="phone" id="phone" class="regular-text" value="<?php echo esc_attr($donor->phone); ?>" required><br>

    <label for="blood_type">Select Blood Group</label><br>
    <select name="blood_type" id="blood_type" required>
        <?php
        $groups = ['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-'];
        foreach ($groups as $group) {
            $selected = ($donor->blood_group === $group) ? 'selected' : '';
            echo "<option value='$group' $selected>$group</option>";
        }
        ?>
    </select><br><br>

    <label for="status">Status</label><br>
    <select name="status" id="status" required>
        <?php
        $statuses = ['yes', 'no'];
        foreach ($statuses as $status_option) {
            $selected = ($donor->status === $status_option) ? 'selected' : '';
            echo "<option value='$status_option' $selected>$status_option</option>";
        }
        ?>
    </select><br><br>

    <input type="submit" name="update" value="Update" class="button button-primary">
</form>
