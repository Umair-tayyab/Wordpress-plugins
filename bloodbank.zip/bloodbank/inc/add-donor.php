<?php
echo "<div class='wrap'><h2>Add Donor </h2><p>Please add donor carefully.</p></div>";

global $wpdb;
$table_name = $wpdb -> prefix . "bloodbank";

if (isset($_POST['submit'])) {
    $name = sanitize_text_field($_POST['name']);
    $email = sanitize_email($_POST['email']);
    $phone = sanitize_text_field($_POST['phone']);
    $blood_type = sanitize_text_field($_POST['blood_type']);
    $status = sanitize_text_field($_POST['status']);
    $result = $wpdb -> insert(
        $table_name,
        array(
            'name' => $name,
            'email' => $email,
            'phone' => $phone,
            'blood_group' => $blood_type,
            'status' => $status,
        )
    );
    if ($result) {
        echo "<div class='notice notice-success is-dismissible'><p>Donor added successfully!</p></div>";
    }else{
        echo "<div class='notice notice-error is-dismissible'><p>Donor not added. Error: " . $wpdb->last_error . "</p></div>";
    }
}

?>

<form action="" method="POST">
    <label for="name">Name</label><br>
    <input type="text" name="name" id="name" class="regular-text" required><br>

    <label for="email">Email</label><br>
    <input type="email" name="email" id="email" class="regular-text" required><br>

    <label for="phone">Phone</label><br>
    <input type="text" name="phone" id="phone" class="regular-text" required><br>

    <label for="blood_type">Select Blood Group</label><br>
    <select name="blood_type" id="blood_type" required>
        <option value="">Select</option>
        <option value="A+">A+</option>
        <option value="A-">A-</option>
        <option value="B+">B+</option>
        <option value="B-">B-</option>
        <option value="O+">O+</option>
        <option value="O-">O-</option>
        <option value="AB+">AB+</option>
        <option value="AB-">AB-</option>
    </select><br>

    <label for="status">Status</label><br>
    <select name="status" id="status" required>
        <option value="yes">Yes</option>
        <option value="no">No</option>
    </select><br>

    <input type="submit" name="submit" value="Submit" class="button button-primary" style="margin-top:20px;">
</form>
