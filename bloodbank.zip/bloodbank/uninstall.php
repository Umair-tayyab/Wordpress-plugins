<?php

global $wpdb;
$table_name = $wpdb -> prefix . "bloodbank";
$sql = "DROP TABLE `wpbloodbank`.`$table_name`";
$wpdb -> quey($sql);