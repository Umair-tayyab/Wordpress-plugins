<?php
/**
 * Plugin Name: BloodBank
 * Version: 1.0.0
 * Author: Umair Tayyab
 * Author uri: Umairtayyb.com
 * Description: A simple blood bank plugin for WordPress.
 * License: GPL2
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: bloodbank
 * Domain Path: /languages
 * Requires at least: 5.0
 * Requires PHP: 7.0
 */

if (!defined('ABSPATH')) {
    wp_die("You can't be here");
}

function add_js(){
    wp_enqueue_script('script', plugin_dir_url(__FILE__) . 'src/app.js', array(), filemtime(plugin_dir_path(__FILE__) . 'src/app.js'), true);
    // wp_add_inline_script('script', 'var ajaxurl = "'. admin_url('admin-ajax.php') .'";', 'before');
}
add_action('wp_enqueue_scripts', 'add_js');
// add_action('admin_enqueue_scripts', 'add_js');

function bloodbank_activation(){
    global $wpdb;
    $table_name = $wpdb -> prefix . "bloodbank";
    $sql = $sql = "CREATE TABLE `wpbloodbank`.`$table_name` (
                    `id` INT NOT NULL AUTO_INCREMENT,
                    `name` VARCHAR(100) NOT NULL,
                    `email` VARCHAR(100) NOT NULL,
                    `phone` VARCHAR(20) NOT NULL,
                    `blood_group` VARCHAR(100) NOT NULL,
                    `status` VARCHAR(10) DEFAULT NULL,
                    PRIMARY KEY (`id`)
                ) ENGINE = InnoDB;";
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);


}
register_activation_hook(__FILE__, 'bloodbank_activation');

function add_donor_role(){
        add_role(
            'blood_donor',
            'Blood Donor',
            array(
                'read' => true,
                'edit_post' => false,
                'delete_post' => false,
            )
        );
}
register_activation_hook(__FILE__, 'add_donor_role');


function bloodbank_deactivation(){
    global $wpdb;
    $table_name = $wpdb -> prefix . "bloodbank";
    $sql = "TRUNCATE TABLE `wpbloodbank`.`$table_name`";
    $wpdb -> query($sql);
    remove_role('donor');
}
register_activation_hook(__FILE__, 'bloodbank_deactivation');

function bloodbank_menupage(){
    add_menu_page('Blood Bank', 'Blood Bank', 'manage_options', 'bloodbank', 'bloodbank', 'dashicons-list-view', 10);
    add_submenu_page(null, 'pending','Pending', 'manage_options', 'bloodbank-pending', 'bloodbank_pending');
    add_submenu_page(null, 'published','Published', 'manage_options', 'bloodbank-published', 'bloodbank_published');
    add_submenu_page('bloodbank', 'Add Donor','Add Donor', 'manage_options', 'add-donor', 'add_donor');
    add_submenu_page(null, 'Delete Donor','Delete Donor', 'manage_options', 'delete-donor', 'delete_donor');
    add_submenu_page(null, 'Update Donor','Update Donor', 'manage_options', 'update-donor', 'update_donor');

}
add_action('admin_menu', 'bloodbank_menupage');

function bloodbank(){
    include "inc/bloodbank.php";
}

function bloodbank_pending(){
    include "inc/bloodbank-pending.php";
}

function bloodbank_published(){
    include "inc/bloodbank-published.php";
}

function add_donor(){
    include "inc/add-donor.php";
}

function delete_donor(){
    include "inc/delete-donor.php";
}

function update_donor(){
    include "inc/update-donor.php";
}

function home_signup(){
    ob_start();
    include "inc/home-bloodbank.php";
    return ob_get_clean();
}
add_shortcode('front_donor', 'home_signup');

function donor_signup(){
    ob_start();
    include "inc/signup.php";
    return ob_get_clean();
}
add_shortcode('signup_form', 'donor_signup');

function donor_login(){
    ob_start();
    include "inc/login.php";
    return ob_get_clean();
}
add_shortcode('login_form', 'donor_login');

function donor_profile(){
    ob_start();
    include "inc/donor-profile.php";
    return ob_get_clean();
}
add_shortcode('donor_profile', 'donor_profile');


function login_form_logic(){
        if (isset($_POST['userlogin'])) {
        $username = sanitize_user($_POST['usrname']);
        $password = $_POST['userpassword'];

        $credentials = array(
            'user_login' => $username,
            'user_password' => $password,
            'remember' => true
        );

        $user = wp_signon($credentials, false);

        if (is_wp_error($user)) {
            echo "Login failed: " . $user->get_error_message();
        }else{
            wp_redirect(home_url('user_profile'));
            echo "User login successfully!";
            echo "<pre>";
            print_r($user);
            echo "</pre>";
        }
    }
}
add_action('template_redirect', 'login_form_logic');


function signin_form_logic(){
    global $wpdb;
    $table_name = $wpdb -> prefix . "bloodbank";
    if (isset($_POST['usersignup'])) {
        $username = sanitize_user($_POST['usrname']);
        $useremail = sanitize_email($_POST['useremail']);
        $userpassword = $_POST['userpassword'];
        $user_id = wp_create_user($username, $userpassword, $useremail);
        // echo $user_id;
        if (is_wp_error($user_id)) {
            echo "Login failed: " . $user_id->get_error_message();
        }else{
            $user = new WP_User($user_id);
            $user -> set_role('blood_donor');

            wp_redirect(home_url('/user-login'));
            exit;
        }
    }
}
add_action('template_redirect', 'signin_form_logic');

function after_setup_theme_tool_bar(){
    if (!current_user_can('administrator')) {
        show_admin_bar(false);
    }
}
    
add_action('after_setup_theme', 'after_setup_theme_tool_bar');